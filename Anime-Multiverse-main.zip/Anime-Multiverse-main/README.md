# Anime-Multiverse

Newest Update :

**New Anime Nations**

- "Kaifuku Jutsushi no Yarinaoshi"

- "Sekai Saikou no Ansatsusha"

**New Characters**

**Lugh (Unique to Sekai Saikou no Ansatsusha)**

- Uniques : Earn +20% of the damage done to Military units as Gold

- Promotions (Rapid Recovery) : Unit will heal every turn, even if it performs an action

- Promotions (Summon Gungnir) : Can carry 1 Gungnir units

**Gungnir (Unique to Sekai Saikou no Ansatsusha)**

- Uniques : Nuclear weapon of Strength 1, Blast radius 2

**Keyaru (Unique to Kaifuku Jutsushi no Yarinaoshi)**

- Uniques : All adjacent units heal +10 HP when healing

- Promotions (Memory Manipulation) : May capture killed Military units

**Other**

- "Changes building "Coffee Shop" to "LycoReco""

- "Added anime attack sounds for Sniper unit"

NOTE : This mod is still WIP, there will be new characters and buildings and there may be slight changes to the character's abilities to make the game more balanced.

If you have any requests or suggestions, feel free to contact me! 🙏

